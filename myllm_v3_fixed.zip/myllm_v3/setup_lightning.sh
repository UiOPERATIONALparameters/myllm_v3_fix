#!/bin/bash
# setup_lightning.sh — Run this in your Lightning AI Studio terminal.
#
# Usage:
#   unzip myllm_v3.zip
#   cd myllm_v3
#   bash setup_lightning.sh

set -e

echo "=== All-rounder 135M Setup (v2 — memory-safe data prep) ==="
echo ""

echo "Step 1: Installing dependencies..."
pip install -q --upgrade -r requirements.txt
# psutil is REQUIRED by the new memory-safe data prep (RAM monitor + resume)
pip install -q psutil
echo "OK: Dependencies installed (incl. psutil for RAM monitoring)"
echo ""

echo "Step 2: Enabling fast HF downloads (5-10x speedup)..."
export HF_HUB_ENABLE_HF_TRANSFER=1
# Persist for future terminal sessions in this Studio
grep -q "HF_HUB_ENABLE_HF_TRANSFER" ~/.bashrc 2>/dev/null \
  || echo 'export HF_HUB_ENABLE_HF_TRANSFER=1' >> ~/.bashrc
echo "OK: HF transfer enabled (persisted to ~/.bashrc)"
echo ""

echo "Step 3: (OPTIONAL) HuggingFace login — needed only if you want to use gated code datasets."
echo "  The new data prep script uses OPEN datasets by default, so you can SKIP this."
echo "  To enable gated datasets (bigcode/starcoder2, the-stack-smol) anyway:"
echo "    huggingface-cli login"
echo "    # Paste a token from https://huggingface.co/settings/tokens"
echo "    # Then visit the dataset page on the Hub and click 'Agree and access repository'"
echo ""

echo "Step 4: Verifying project structure..."
ls -la *.py data/*.py
echo ""

echo "Step 5: Checking available RAM (data prep needs >= 8 GB, recommended 16 GB)..."
python -c "
import psutil
vm = psutil.virtual_memory()
print(f'Total RAM:     {vm.total/1e9:.1f} GB')
print(f'Available RAM: {vm.available/1e9:.1f} GB')
print(f'Used:          {vm.used/1e9:.1f} GB ({vm.percent:.0f}%)')
if vm.total < 8e9:
    print('WARNING: < 8 GB RAM. Data prep will likely OOM. Switch to a larger CPU machine.')
elif vm.total < 16e9:
    print('OK: 8-16 GB RAM. Data prep will work but may be slow under memory pressure.')
else:
    print('OK: >= 16 GB RAM. Comfortable for data prep.')
"
echo ""

echo "Step 6: Checking disk space (data prep needs ~30 GB peak)..."
df -h . | head -2
echo ""

echo "Step 7: Checking GPU availability..."
python -c "
import torch
if torch.cuda.is_available():
    name = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    vram = torch.cuda.get_device_properties(0).total_memory / 1e9
    print(f'GPU: {name}')
    print(f'Compute capability: sm_{cap[0]}{cap[1]}')
    print(f'VRAM: {vram:.1f} GB')
    if cap[0] >= 8:
        print(f'OK: BF16 supported.')
    else:
        print(f'WARNING: This GPU (sm_{cap[0]}{cap[1]}) does NOT support BF16.')
        print(f'You MUST use H100, H200, A100, or L40S. NOT T4.')
else:
    print('No GPU detected. This is FINE for data prep (Step 8).')
    print('Switch to H100 only when you are ready to train (Step 9).')
"
echo ""

echo "Step 8: Verifying config and param count..."
python config_v3.py
echo ""

echo "=== Setup complete! ==="
echo ""
echo "NEXT STEPS:"
echo ""
echo "1. Prepare the 5B token dataset (free CPU, ~60-90 min):"
echo "   python data/prepare_5b_allrounder.py"
echo "   # Memory-safe v2: all datasets streamed, gc between sources,"
echo "   # auto-resume from crash via data/allrounder_5b/progress.json"
echo ""
echo "2. Switch to H100 80GB (top-right machine selector -> H100)"
echo "   Cost: ~\$4.50/hour. Total training: ~3 hours = ~\$13.50"
echo ""
echo "3. Start pretraining (on H100, ~2.5 hours):"
echo "   python train_v3.py"
echo ""
echo "4. After pretraining, do SFT (~30 min on H100):"
echo "   python sft_v3.py --base out/allrounder_135M/ckpt_best.pt"
echo ""
echo "5. Chat with your model:"
echo "   python sample_v3.py --checkpoint out/allrounder_135M_sft/ckpt_sft.pt --interactive"
echo ""
echo "Total expected cost: ~\$14 (pretraining) + ~\$2 (SFT) = ~\$16"
echo "If tight on budget, skip SFT and use the base model for completion."
echo ""
echo "IF DATA PREP CRASHES (network, OOM, manual Ctrl-C):"
echo "  Just re-run:  python data/prepare_5b_allrounder.py"
echo "  It will resume from the last completed source via progress.json."
echo "  To start completely fresh:  rm -rf data/allrounder_5b"
