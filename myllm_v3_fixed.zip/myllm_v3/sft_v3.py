"""
sft_v3.py — Supervised fine-tuning to make the 135M base model chattable.

A base LM (output of train_v3.py) is NOT chattable — it just completes text.
This script does SFT on a chat dataset to teach it to follow instructions.

WHAT IT DOES
------------
  - Loads the pretrained 135M base model
  - Trains on OpenHermes-2.5 (or SmolTalk) with ChatML template
  - Masks the prompt tokens (only compute loss on assistant responses)
  - Uses lower LR (5e-5) and fewer steps (~2000)
  - Saves to out/allrounder_135M_sft/

ESTIMATED COST
--------------
  - Dataset: ~200M tokens of instruction data (subset of OpenHermes-2.5)
  - FLOPs: 6 x 135M x 200M = 1.6e17 (tiny)
  - Wall-clock on H100: ~20-30 min
  - Cost: ~$2.25 at $4.50/hr

USAGE
-----
    python sft_v3.py --base out/allrounder_135M/ckpt_best.pt
    python sft_v3.py --base out/allrounder_135M/ckpt_best.pt --dataset smoltalk
"""

import argparse
import os
import time
import math
import json
from contextlib import nullcontext

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config_v3 import GPTConfigV3, save_config
from model_v3 import GPT


# ---------------------------------------------------------------------------
# ChatML template (OpenAI / SmolLM2 / Qwen convention)
# ---------------------------------------------------------------------------
CHATML_TEMPLATE = """<|im_start|>system
{system}<|im_end|>
<|im_start|>user
{user}<|im_end|>
<|im_start|>assistant
{assistant}<|im_end|>"""


def format_chatml(conversation, enc):
    """Convert a conversation [{from, value}] into (prompt_ids, response_ids).

    Returns:
        prompt_ids: tokens of system + user turns (will be MASKED in loss)
        response_ids: tokens of the assistant turn (loss is computed here)
    """
    system_msg = "You are a helpful assistant."
    user_msgs = []
    assistant_msgs = []
    for turn in conversation:
        role = turn.get("from", "human").lower()
        val = turn.get("value", "")
        if role in ("system",):
            system_msg = val
        elif role in ("human", "user"):
            user_msgs.append(val)
        elif role in ("gpt", "assistant"):
            assistant_msgs.append(val)

    if not user_msgs or not assistant_msgs:
        return None, None

    # Build prompt: system + all user turns (last one is the question)
    prompt_parts = [f"<|im_start|>system\n{system_msg}<|im_end|>\n"]
    for i, u in enumerate(user_msgs):
        prompt_parts.append(f"<|im_start|>user\n{u}<|im_end|>\n")
    prompt_text = "".join(prompt_parts)
    prompt_ids = enc.encode_ordinary(prompt_text)

    # Build response: assistant turn + end token
    response_text = f"<|im_start|>assistant\n{assistant_msgs[-1]}<|im_end|>"
    response_ids = enc.encode_ordinary(response_text)
    response_ids.append(enc.eot_token)

    return prompt_ids, response_ids


# ---------------------------------------------------------------------------
# SFT dataset — tokenized on-the-fly, packed to fixed length
# ---------------------------------------------------------------------------
class SFTDataset:
    def __init__(self, hf_dataset, enc, block_size: int, max_examples: int = 200_000):
        self.enc = enc
        self.block_size = block_size
        self.examples = []

        print(f"  Tokenizing SFT dataset (max {max_examples} examples)...")
        n_added = 0
        for doc in hf_dataset:
            if n_added >= max_examples:
                break
            convs = doc.get("conversations", [])
            if not convs:
                continue
            prompt_ids, response_ids = format_chatml(convs, enc)
            if prompt_ids is None or response_ids is None:
                continue
            # Truncate prompt if too long (keep last tokens)
            max_prompt = block_size - len(response_ids) - 1
            if max_prompt < 32:
                continue  # response too long, skip
            if len(prompt_ids) > max_prompt:
                prompt_ids = prompt_ids[-max_prompt:]

            # Build input/target: prompt + response
            input_ids = prompt_ids + response_ids
            # Pad to block_size if needed (with ignore_index=-1 for loss)
            target = list(input_ids) + [-1] * (block_size - len(input_ids))
            input_padded = input_ids + [enc.eot_token] * (block_size - len(input_ids))

            # Mask prompt tokens in target (set to -1 so loss ignores them)
            for i in range(len(prompt_ids)):
                target[i] = -1

            self.examples.append((input_padded, target))
            n_added += 1
            if n_added % 10000 == 0:
                print(f"    {n_added} examples tokenized")

        print(f"  SFT dataset ready: {len(self.examples)} examples")

    def __len__(self):
        return len(self.examples)

    def get_batch(self, batch_size: int, device: torch.device):
        idx = np.random.randint(0, len(self), size=batch_size)
        x = np.array([self.examples[i][0] for i in idx], dtype=np.int64)
        y = np.array([self.examples[i][1] for i in idx], dtype=np.int64)
        x = torch.from_numpy(x)
        y = torch.from_numpy(y)
        if device.type == "cuda":
            x = x.pin_memory().to(device, non_blocking=True)
            y = y.pin_memory().to(device, non_blocking=True)
        else:
            x = x.to(device)
            y = y.to(device)
        return x, y


# ---------------------------------------------------------------------------
# Main SFT training
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=str, required=True, help="Path to base model checkpoint")
    parser.add_argument("--dataset", type=str, default="openhermes",
                        choices=["openhermes", "smoltalk"],
                        help="SFT dataset to use")
    parser.add_argument("--device", type=str, default=None)
    parser.add_argument("--max-iters", type=int, default=2000)
    parser.add_argument("--lr", type=float, default=5e-5)
    args = parser.parse_args()

    # --- load base model ---
    print(f"Loading base model: {args.base}")
    ckpt = torch.load(args.base, map_location="cpu", weights_only=False)
    cfg = GPTConfigV3(**ckpt["config"])

    # --- device ---
    if args.device:
        device = torch.device(args.device)
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
    print(f"Using device: {device}")

    # --- TF32 ---
    if device.type == "cuda":
        torch.set_float32_matmul_precision("high")
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        print("  TF32 enabled")

    # --- autocast ---
    ptdtype = torch.bfloat16
    ctx = torch.amp.autocast(device_type="cuda", dtype=ptdtype) if device.type == "cuda" else nullcontext()

    # --- model ---
    model = GPT(cfg).to(device)
    state_dict = ckpt["model"]
    if any(k.startswith("_orig_mod.") for k in state_dict):
        state_dict = {k.replace("_orig_mod.", "", 1): v for k, v in state_dict.items()}
    model.load_state_dict(state_dict)
    print(f"  loaded: {model.num_params()/1e6:.2f}M params")

    if hasattr(torch, "compile") and device.type == "cuda":
        try:
            model = torch.compile(model)
            print("  torch.compile() enabled")
        except Exception as e:
            print(f"  torch.compile() failed: {e}")

    # --- tokenizer ---
    import tiktoken
    enc = tiktoken.get_encoding("gpt2")

    # --- SFT dataset ---
    print(f"Loading SFT dataset: {args.dataset}")
    from datasets import load_dataset
    if args.dataset == "openhermes":
        sft_data = load_dataset("teknium/OpenHermes-2.5", split="train")
    else:  # smoltalk
        sft_data = load_dataset("HuggingFaceTB/smoltalk", "all", split="train")

    sft_ds = SFTDataset(sft_data, enc, cfg.block_size, max_examples=200_000)

    # Hold out 1000 examples for val
    val_examples = sft_ds.examples[-1000:]
    sft_ds.examples = sft_ds.examples[:-1000]

    # --- optimizer (same as pretraining, lower LR) ---
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if p.dim() >= 2 and "emb" not in name:
            decay.append(p)
        else:
            no_decay.append(p)
    groups = [
        {"params": decay,    "weight_decay": 0.1},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    optimizer = torch.optim.AdamW(
        groups, lr=args.lr,
        betas=(0.9, 0.95), eps=1e-8,
        fused=(device.type == "cuda"),
    )
    print(f"  optimizer: AdamW lr={args.lr} (10x lower than pretraining)")

    # --- output ---
    out_dir = "out/allrounder_135M_sft"
    os.makedirs(out_dir, exist_ok=True)

    # --- training loop ---
    print(f"\n=== SFT start (max_iters={args.max_iters}) ===")
    batch_size = 8
    grad_accum = 8  # smaller grad accum for SFT (shorter steps)
    print(f"  Effective batch: {batch_size * cfg.block_size * grad_accum / 1e6:.2f}M tok/step")

    t0 = time.time()
    model.train()
    running_loss = 0.0
    running_count = 0

    for step in range(1, args.max_iters + 1):
        # Cosine decay from args.lr to args.lr * 0.1
        decay_ratio = step / args.max_iters
        coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
        lr = args.lr * 0.1 + coeff * (args.lr - args.lr * 0.1)
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        step_loss_t = torch.zeros((), device=device)
        for _ in range(grad_accum):
            x, y = sft_ds.get_batch(batch_size, device)
            with ctx:
                _, loss, _, _ = model(x, y)
            if not torch.isfinite(loss):
                raise RuntimeError(f"Non-finite loss at SFT step {step}: {loss.item()}")
            loss = loss / grad_accum
            loss.backward()
            step_loss_t += loss.detach()
        running_loss += step_loss_t.item()
        running_count += 1

        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        if step % 10 == 0:
            avg = running_loss / running_count
            running_loss = 0.0
            running_count = 0
            elapsed = time.time() - t0
            eta_sec = (elapsed / step) * (args.max_iters - step)
            print(f"sft step {step:>5d}  loss {avg:.4f}  lr {lr:.2e}  ETA {eta_sec/60:.1f}min")

        # Eval + checkpoint every 500 steps
        if step % 500 == 0 or step == args.max_iters:
            # Quick val
            model.eval()
            with torch.no_grad():
                val_losses = []
                for i in range(min(50, len(val_examples))):
                    x = torch.tensor([val_examples[i][0]], dtype=torch.long, device=device)
                    y = torch.tensor([val_examples[i][1]], dtype=torch.long, device=device)
                    with ctx:
                        _, _, ce, _ = model(x, y)
                    val_losses.append(ce.item())
                val_loss = sum(val_losses) / len(val_losses)
            model.train()
            print(f"  >> sft step {step}  val_loss {val_loss:.4f}")

            # Save checkpoint
            state_dict = model.state_dict() if not hasattr(model, "_orig_mod") else model._orig_mod.state_dict()
            state_dict = {(k.replace("_orig_mod.", "", 1) if k.startswith("_orig_mod.") else k): v
                          for k, v in state_dict.items()}
            torch.save({
                "model": state_dict,
                "step": step,
                "config": cfg.__dict__,
                "base_model": args.base,
                "sft_dataset": args.dataset,
            }, os.path.join(out_dir, "ckpt_sft.pt"))
            print(f"  -> SFT checkpoint saved: {out_dir}/ckpt_sft.pt")

    print(f"\n=== SFT complete ===")
    print(f"  Final: {out_dir}/ckpt_sft.pt")
    print(f"  To chat: python sample_v3.py --checkpoint {out_dir}/ckpt_sft.pt --interactive")


if __name__ == "__main__":
    main()
