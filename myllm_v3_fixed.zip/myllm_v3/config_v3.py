"""
config_v3.py — Configuration for the 135M "all-rounder" model (v3).

ARCHITECTURE: SmolLM2-135M-style deep-narrow transformer
  - 30 layers, n_embd=576, 9 query heads, 3 KV heads (GQA 3:1)
  - head_dim = 64 (proven sweet spot)
  - SwiGLU MLP with intermediate=1536 (= 8/3 * 576, mult of 64)
  - Tied embeddings (saves 29M params)
  - Pre-RMSNorm, eps=1e-5
  - RoPE theta=100000 (correct for 2048 context, supports extension)
  - QK-norm (cheap stability insurance)
  - Z-loss alpha=1e-4 (logit norm penalty)
  - No biases anywhere

WHY 135M (not 200M):
  - At $14.89 budget on H100 @ $4.50/hr, you have ~3 hours of compute.
  - 135M x 5B tokens = 4.05e18 FLOPs (modern 37x Chinchilla overtraining)
  - 200M x 4B tokens = 4.8e18 FLOPs (1x Chinchilla, severely undertrained by 2025 standards)
  - Modern research (SmolLM2, MobileLLM) shows MORE TOKENS > MORE PARAMS at small scale.
  - 135M + 5B + SFT fits in $13.63; 200M + 4B + SFT is $1+ over budget.

PARAM COUNT
-----------
  - Embedding (tied): 50304 x 576 = 28.97M (counted once)
  - Per-block:
      * qkv proj:    576 x (576 + 2x192) = 0.553M
      * o proj:      576 x 576 = 0.332M
      * SwiGLU:      3 x 576 x 1536 = 2.65M
      * 2 RMSNorm:   2 x 576 = 1.15K
      * 2 QK-norm:   2 x 64 = 128
      * Block total: ~3.54M
  - 30 blocks x 3.54M = 106.2M
  - Final RMSNorm: 576
  - TOTAL: 28.97M + 106.2M + 0.0006M = 135.2M

Reference: HuggingFace SmolLM2-135M (released Oct 2024, still SOTA for ~135M in 2025).
"""

from dataclasses import dataclass, asdict
import json
import os


@dataclass
class GPTConfigV3:
    # === ARCHITECTURE (SmolLM2-135M style, deep-narrow) ===
    vocab_size: int = 50304          # GPT-2 BPE (tiktoken), mult of 64
    block_size: int = 2048           # context length (2x v2; modern standard)
    n_layer: int = 30                # DEEP (was 13 in v2; deep-narrow wins at <500M)
    n_head: int = 9                  # query heads
    n_kv_head: int = 3               # KV heads (GQA 3:1)
    n_embd: int = 576                # NARROW (was 1024 in v2)
    intermediate_size: int = 1536    # SwiGLU hidden (= 8/3 * 576, mult of 64)
    tie_embeddings: bool = True      # tie input emb and output head (saves 29M)
    norm_eps: float = 1e-5           # RMSNorm epsilon
    rope_theta: float = 100000.0     # RoPE base (100k for 2048+ context; was 10k in v2)
    qk_norm: bool = True             # RMSNorm on Q/K before RoPE (stability)
    z_loss_weight: float = 1e-4      # logit norm penalty (stability)
    dropout: float = 0.0             # off for large-scale training
    bias: bool = False               # no biases anywhere

    # === OPTIMIZER ===
    learning_rate: float = 4e-4      # peak LR (SmolLM2-135M uses 3e-4; 4e-4 is safe upper bound)
    min_lr_ratio: float = 0.1        # min_lr = learning_rate * 0.1
    weight_decay: float = 0.1        # on 2D weights only (NOT embeddings/norms)
    beta1: float = 0.9
    beta2: float = 0.95              # CRITICAL: 0.95, NOT 0.999
    eps: float = 1e-8
    grad_clip: float = 1.0           # L2 norm clipping

    # === TRAINING SCHEDULE ===
    # 5B tokens / 0.5M tokens-per-step = 10000 steps
    # 2% warmup = 200 steps (SmolLM2 uses 2000; we use 200 for shorter runs)
    max_iters: int = 10000
    warmup_iters: int = 200
    lr_decay_iters: int = 10000      # cosine decays over full run

    # === BATCH ===
    # Effective batch = micro_bs * seq * grad_accum = 8 * 2048 * 32 = 524288 tokens
    # = 0.5M tokens per step (SmolLM2 standard)
    batch_size: int = 8              # micro batch (fits H100 80GB easily with bf16)
    grad_accum_steps: int = 32       # accumulate 32 micro-batches per step

    # === EVAL / CHECKPOINTING ===
    eval_interval: int = 250         # eval val loss every 250 steps
    eval_iters: int = 50             # batches per eval
    log_interval: int = 10           # print train loss every 10 steps
    checkpoint_interval: int = 1000  # save every 1000 steps
    sample_interval: int = 1000      # generate sample text every 1000 steps
    keep_last_n_checkpoints: int = 3 # auto-cleanup old checkpoints

    # === DATA ===
    data_dir: str = "data"
    dataset: str = "allrounder_5b"   # 50/20/15/10/5 FineWeb-Edu/Wiki/StarCoder/OpenHermes/FineMath
    val_tokens: int = 5_000_000      # 5M val tokens (held out, mixed sources)

    # === PATHS / RUN ===
    out_dir: str = "out"
    run_name: str = "allrounder_135M"
    dtype: str = "bfloat16"          # bf16 (H100 native; do NOT use T4 — no BF16 support)
    compile: bool = True             # torch.compile for speed
    tf32: bool = True                # enable TF32 for FP32 matmuls (3-8x speedup)


# Singleton
def get_config() -> GPTConfigV3:
    return GPTConfigV3()


def save_config(cfg: GPTConfigV3, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(asdict(cfg), f, indent=2)


def load_config(path: str) -> GPTConfigV3:
    with open(path) as f:
        return GPTConfigV3(**json.load(f))


if __name__ == "__main__":
    cfg = get_config()

    # Approximate param count
    emb = cfg.vocab_size * cfg.n_embd
    head_dim = cfg.n_embd // cfg.n_head
    kv_dim = cfg.n_kv_head * head_dim
    per_block = (
        cfg.n_embd * (cfg.n_embd + 2 * kv_dim) +
        cfg.n_embd * cfg.n_embd +
        3 * cfg.n_embd * cfg.intermediate_size +
        2 * cfg.n_embd +
        2 * head_dim  # QK-norm
    )
    body = cfg.n_layer * per_block + cfg.n_embd
    total = emb + body if cfg.tie_embeddings else emb + body + cfg.vocab_size * cfg.n_embd

    print(f"=== All-rounder 135M config (v3) ===")
    print(f"  Architecture: {cfg.n_layer}L {cfg.n_head}H/{cfg.n_kv_head}KV {cfg.n_embd}D (head_dim={head_dim})")
    print(f"  Context:      {cfg.block_size}")
    print(f"  GQA ratio:    {cfg.n_head // cfg.n_kv_head}:1")
    print(f"  Tied emb:     {cfg.tie_embeddings}")
    print(f"  QK-norm:      {cfg.qk_norm}")
    print(f"  Z-loss:       {cfg.z_loss_weight}")
    print(f"  Total params: {total/1e6:.1f}M")
    print()
    print(f"  Training:     {cfg.max_iters} steps, {cfg.max_iters * cfg.batch_size * cfg.block_size * cfg.grad_accum_steps / 1e9:.1f}B tokens")
    print(f"  LR:           {cfg.learning_rate} -> {cfg.learning_rate * cfg.min_lr_ratio}")
    print(f"  Batch:        {cfg.batch_size} micro x {cfg.grad_accum_steps} accum = "
          f"{cfg.batch_size * cfg.block_size * cfg.grad_accum_steps / 1e6:.2f}M tok/step")
    print(f"  Optimizer:    AdamW(b1={cfg.beta1}, b2={cfg.beta2}, eps={cfg.eps})")
    print(f"  Weight decay: {cfg.weight_decay} (2D only)")
    print(f"  Grad clip:    {cfg.grad_clip}")
    print(f"  Dtype:        {cfg.dtype} (TF32={cfg.tf32})")
    print()
    print(f"  Dataset:      {cfg.dataset}")
    print(f"  Run name:     {cfg.run_name}")
    print()
    # Compute estimate
    flops = 6 * total * cfg.max_iters * cfg.batch_size * cfg.block_size * cfg.grad_accum_steps
    print(f"  Compute:      {flops:.2e} FLOPs")
    print(f"  H100 @ 45% MFU: {flops / (989e12 * 0.45) / 3600:.2f} hours = ${flops / (989e12 * 0.45) / 3600 * 4.50:.2f}")
