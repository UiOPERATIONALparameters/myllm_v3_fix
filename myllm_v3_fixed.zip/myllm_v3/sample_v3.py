"""
sample_v3.py — Generate text from the trained 135M model (base or SFT).

USAGE
-----
    # One-shot generation
    python sample_v3.py --checkpoint out/allrounder_135M/ckpt_best.pt --prompt "The Eiffel Tower is"

    # Interactive chat (works best after SFT)
    python sample_v3.py --checkpoint out/allrounder_135M_sft/ckpt_sft.pt --interactive
"""

import argparse
import os
import sys
import torch
import tiktoken

from config_v3 import GPTConfigV3
from model_v3 import GPT


def load_model(checkpoint_path, device):
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    cfg = GPTConfigV3(**ckpt["config"])

    model = GPT(cfg).to(device)
    state_dict = ckpt["model"]
    if any(k.startswith("_orig_mod.") for k in state_dict):
        state_dict = {k.replace("_orig_mod.", "", 1): v for k, v in state_dict.items()}
    model.load_state_dict(state_dict)
    model.eval()

    print(f"Loaded: {checkpoint_path}")
    print(f"  step: {ckpt.get('step')}  val_loss: {ckpt.get('best_val_loss', '?')}")
    print(f"  params: {model.num_params()/1e6:.2f}M  ctx: {cfg.block_size}")
    print(f"  GQA: {cfg.n_head}Q/{cfg.n_kv_head}KV ({cfg.n_head // cfg.n_kv_head}:1)")
    return model, cfg


def chatml_prompt(user_msg, system_msg="You are a helpful assistant."):
    return (
        f"<|im_start|>system\n{system_msg}<|im_end|>\n"
        f"<|im_start|>user\n{user_msg}<|im_end|>\n"
        f"<|im_start|>assistant\n"
    )


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--prompt", type=str, default=None)
    p.add_argument("--max-new-tokens", type=int, default=300)
    p.add_argument("--temperature", type=float, default=0.7)
    p.add_argument("--top-k", type=int, default=50)
    p.add_argument("--top-p", type=float, default=0.9)
    p.add_argument("--interactive", action="store_true")
    p.add_argument("--chat", action="store_true",
                   help="Use ChatML template (for SFT models)")
    p.add_argument("--device", type=str, default=None)
    args = p.parse_args()

    if args.device:
        device = torch.device(args.device)
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    print(f"Using device: {device}")

    # Enable TF32 even for inference
    if device.type == "cuda":
        torch.set_float32_matmul_precision("high")
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    model, cfg = load_model(args.checkpoint, device)
    enc = tiktoken.get_encoding("gpt2")

    is_chat_mode = args.interactive or args.chat

    if args.interactive:
        print("\n=== Interactive mode ===")
        if is_chat_mode and "sft" in args.checkpoint:
            print("ChatML mode (for SFT model). Type your message + Enter. 'quit' to exit.\n")
        else:
            print("Raw completion mode. Type your prompt + Enter. 'quit' to exit.\n")

        while True:
            try:
                user_input = input(">>> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nbye")
                break
            if user_input.lower() in {"quit", "exit", "q"}:
                break
            if not user_input:
                continue

            if is_chat_mode and "sft" in args.checkpoint:
                prompt = chatml_prompt(user_input)
            else:
                prompt = user_input

            _generate_and_print(model, enc, prompt, args, device, is_chat=(is_chat_mode and "sft" in args.checkpoint))
        return

    # One-shot
    if is_chat_mode and "sft" in args.checkpoint and args.prompt:
        prompt = chatml_prompt(args.prompt)
    else:
        prompt = args.prompt or "The Eiffel Tower is"

    _generate_and_print(model, enc, prompt, args, device, is_chat=is_chat_mode)


def _generate_and_print(model, enc, prompt, args, device, is_chat=False):
    ids = enc.encode_ordinary(prompt)
    if len(ids) == 0:
        ids = [enc.eot_token]
    max_ctx = model.cfg.block_size
    if len(ids) > max_ctx:
        ids = ids[-max_ctx:]

    x = torch.tensor([ids], dtype=torch.long, device=device)
    print(f"\n--- prompt ({len(ids)} tokens) ---")
    print(prompt)
    print(f"\n--- generation ({args.max_new_tokens} new tokens, T={args.temperature}, top_k={args.top_k}, top_p={args.top_p}) ---")

    with torch.no_grad():
        out = model.generate(
            x,
            max_new_tokens=args.max_new_tokens,
            temperature=args.temperature,
            top_k=args.top_k if args.top_k > 0 else None,
            top_p=args.top_p,
        )
    text = enc.decode(out[0].tolist())

    if is_chat:
        # For chat mode, only print the assistant's response (after the prompt)
        response = text[len(prompt):]
        # Stop at first <|im_end|>
        if "<|im_end|>" in response:
            response = response.split("<|im_end|>")[0]
        print(response.strip())
    else:
        print(text[len(prompt):])
    print()


if __name__ == "__main__":
    main()
