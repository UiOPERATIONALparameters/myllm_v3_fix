"""
data/prepare_5b_allrounder.py — Build the 5B-token all-rounder dataset.

DATA MIX (5B tokens, modern small-LLM recipe):
  - 50% FineWeb-Edu (2.5B tok)   — high-quality educational web, broad knowledge
  - 20% Wikipedia (1.0B tok)      — encyclopedia facts
  - 15% StarCoder2 (0.75B tok)   — code (programming ability)
  - 10% OpenHermes-2.5 (0.5B tok) — instruction-following + chat-style (helps SFT)
  - 5%  FineMath (0.25B tok)     — math reasoning
  - Total: 5.0B tokens (37x Chinchilla for 135M params — modern overtraining)
  - 5M tokens held out for validation (mixed sources, random sample)

WHY THIS MIX
------------
  - SmolLM2 uses: 50% FineWeb-Edu, 25% Cosmopedia (synthetic), 15% Python-Edu, 10% Web-Math
  - We substitute: Wikipedia for Cosmopedia (cleaner, real text), add OpenHermes for chat ability
  - All sources are HF-curated and well-filtered (FineWeb-Edu score>=4, StarCoder2-Edu, etc.)

OUTPUT
------
  data/allrounder_5b/
    train.bin   (~10.0 GB, 5B uint16 tokens)
    val.bin     (~10 MB, 5M uint16 tokens)
    meta.json   (metadata, source breakdown)
    progress.json  (per-source checkpoint — safe to re-run after a crash)

MEMORY MODEL (CRITICAL — was the source of the original crash)
--------------------------------------------------------------
  - 16 GB RAM free-CPU machine on Lightning AI.
  - ALL datasets MUST be loaded with `streaming=True`. Loading any of them
    non-streaming (especially Wikipedia ~6 GB, OpenHermes ~2-4 GB in Arrow)
    will OOM-kill the process.
  - Between sources we `del dataset; gc.collect()` to release references.
  - We periodically flush the memmap so dirty pages can be reclaimed by the OS.
  - A memory monitor prints RSS every source so you can see pressure building.

RESUME
------
  - Each source writes a checkpoint to progress.json after it finishes.
  - If the script crashes (OOM, network, OOM-kill, manual Ctrl-C), re-running
    will SKIP any source that already has a "done" entry in progress.json
    and CONTINUE from the next one.
  - If you want a totally fresh run, delete data/allrounder_5b/ first.

RUN
---
    python data/prepare_5b_allrounder.py

OPTIONAL — HuggingFace auth (some code datasets are gated)
----------------------------------------------------------
    pip install -q huggingface-hub
    huggingface-cli login    # paste your token from https://huggingface.co/settings/tokens
    # Then on the Hub, open the dataset page and click "Agree and access repository"
    # for: bigcode/starcoder2, bigcode/the-stack-smol (if you want to use them).
    # This script uses OPEN datasets by default, so login is OPTIONAL.
"""

import os
import sys
import json
import time
import random
import gc
import shutil
import psutil
import numpy as np
import tiktoken
from datasets import load_dataset

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "allrounder_5b")
PROGRESS_PATH = os.path.join(DATA_DIR, "progress.json")

# Token targets
FINEWEB_TOKENS    = 2_500_000_000  # 2.5B  (50%)
WIKI_TOKENS       = 1_000_000_000  # 1.0B  (20%)
STARCODER_TOKENS  =   750_000_000  # 0.75B (15%)
OPENHERMES_TOKENS =   500_000_000  # 0.5B  (10%)
FINEMATH_TOKENS   =   250_000_000  # 0.25B (5%)
VAL_TOKENS        =     5_000_000  # 5M val
TOTAL_TRAIN       = (FINEWEB_TOKENS + WIKI_TOKENS + STARCODER_TOKENS
                     + OPENHERMES_TOKENS + FINEMATH_TOKENS)

# Order of sources (defines resume order)
SOURCES = [
    ("fineweb",   FINEWEB_TOKENS),
    ("wikipedia", WIKI_TOKENS),
    ("starcoder", STARCODER_TOKENS),
    ("openhermes", OPENHERMES_TOKENS),
    ("finemath",  FINEMATH_TOKENS),
]


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def fmt_bytes(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def rss_gb():
    """Current process RSS in GB."""
    try:
        return psutil.Process(os.getpid()).memory_info().rss / 1e9
    except Exception:
        return float("nan")


def ram_status():
    """One-line summary of process + system RAM."""
    try:
        vm = psutil.virtual_memory()
        proc = rss_gb()
        return (f"RSS={proc:.2f}GB  "
                f"sys used={vm.used/1e9:.1f}GB / {vm.total/1e9:.1f}GB  "
                f"({vm.percent:.0f}%)  avail={vm.available/1e9:.1f}GB")
    except Exception as e:
        return f"(psutil unavailable: {e})"


# ---------------------------------------------------------------------------
# Streaming dataset loaders
# ---------------------------------------------------------------------------
# Each loader returns an ITERATOR of plain strings. None of them hold the
# full dataset in memory. If a primary dataset is gated / fails, we fall
# back to open datasets that serve the same purpose.
# ---------------------------------------------------------------------------

def iter_fineweb():
    """FineWeb-Edu sample-10BT — open, streaming."""
    ds = load_dataset(
        "HuggingFaceFW/fineweb-edu",
        name="sample-10BT",
        split="train",
        streaming=True,
    )
    for doc in ds:
        text = doc.get("text") or ""
        if text:
            yield text


def iter_wikipedia():
    """wikimedia/wikipedia 20231101.en — open, streaming."""
    ds = load_dataset(
        "wikimedia/wikipedia",
        "20231101.en",
        split="train",
        streaming=True,   # CRITICAL: was non-streaming in v1, caused 6GB RAM
    )
    for doc in ds:
        text = doc.get("text") or ""
        if text:
            yield text


def iter_starcoder():
    """Code data — primary is gated, so we go straight to OPEN alternatives.

    Order tried:
      1. HuggingFaceTB/smollm-corpus  config='starcoder-python-edu'
         (the EXACT code slice SmolLM2 used — open, ~3B tokens of edu-filtered Python)
      2. bigcode/starcoderdata  config='python'  (open, dedup'd raw scrapes)
      3. bigcode/the-stack-smol (gated — last resort, only works if HF login + license accepted)
    """
    # Attempt 1 — SmolLM2's actual code slice (open)
    try:
        ds = load_dataset(
            "HuggingFaceTB/smollm-corpus",
            "starcoder-python-edu",
            split="train",
            streaming=True,
        )
        # Peek one example to validate it actually streams
        it = iter(ds)
        first = next(it, None)
        if first is None:
            raise RuntimeError("empty iterator")
        yield first.get("text") or ""
        for doc in it:
            text = doc.get("text") or ""
            if text:
                yield text
        return
    except Exception as e:
        log(f"  [starcoder] smollm-corpus/starcoder-python-edu failed: {e}")

    # Attempt 2 — bigcode/starcoderdata (open)
    try:
        ds = load_dataset(
            "bigcode/starcoderdata",
            "python",
            split="train",
            streaming=True,
        )
        for doc in ds:
            text = doc.get("content") or ""
            if text:
                yield text
        return
    except Exception as e:
        log(f"  [starcoder] bigcode/starcoderdata failed: {e}")

    # Attempt 3 — gated (needs HF login + license accept on Hub)
    try:
        ds = load_dataset(
            "bigcode/the-stack-smol",
            split="train",
            streaming=True,
        )
        for doc in ds:
            text = doc.get("content") or ""
            if text:
                yield text
        return
    except Exception as e:
        log(f"  [starcoder] bigcode/the-stack-smol failed: {e}")
        log("  [starcoder] ALL code sources failed. "
            "Run `huggingface-cli login` and accept the license at "
            "https://huggingface.co/datasets/bigcode/the-stack-smol")


def iter_openhermes():
    """OpenHermes-2.5 — open, streaming. Flattens conversations to text."""
    ds = load_dataset(
        "teknium/OpenHermes-2.5",
        split="train",
        streaming=True,   # CRITICAL: was non-streaming in v1, caused the OOM kill
    )
    for doc in ds:
        convs = doc.get("conversations") or []
        if not convs:
            continue
        parts = []
        for c in convs:
            role = (c.get("from") or "human").upper()
            val = c.get("value") or ""
            parts.append(f"{role}: {val}")
        text = "\n\n".join(parts)
        if text:
            yield text


def iter_finemath():
    """FineMath-2-plus sample-10BT — open, streaming.
    Fallback: meta-math/MetaMathQA (open, non-streaming ok — small ~400MB)."""
    try:
        ds = load_dataset(
            "HuggingFaceTB/finemath-2-plus",
            name="sample-10BT",
            split="train",
            streaming=True,
        )
        for doc in ds:
            text = doc.get("text") or ""
            if text:
                yield text
    except Exception as e:
        log(f"  [finemath] finemath-2-plus failed: {e}, falling back to MetaMathQA")
        # MetaMathQA is small (~400MB) — safe to load non-streaming
        ds = load_dataset("meta-math/MetaMathQA", split="train")
        for doc in ds:
            q = doc.get("query") or ""
            r = doc.get("response") or ""
            if q or r:
                yield f"{q}\n{r}"


SOURCE_ITERATORS = {
    "fineweb":   iter_fineweb,
    "wikipedia": iter_wikipedia,
    "starcoder": iter_starcoder,
    "openhermes": iter_openhermes,
    "finemath":  iter_finemath,
}


# ---------------------------------------------------------------------------
# Tokenizer + streaming writer
# ---------------------------------------------------------------------------

def tokenize_and_stream(text_iter, train_arr, val_arr, train_pos, val_pos,
                        target_train_tokens, enc, eot, source_name,
                        val_split=0.001, flush_every=50_000):
    """Tokenize an iterable of texts, stream to train_arr (and a small slice to val_arr).

    val_split: fraction of THIS source's tokens that go to val (default 0.1%).
    Mixed-source val is important so val loss reflects the training distribution.

    flush_every: how often (in docs) to call train_arr.flush() so the OS can
    reclaim dirty memmap pages under memory pressure.
    """
    source_train = 0
    source_val = 0
    n_docs = 0

    for text in text_iter:
        if not text or not text.strip():
            continue
        toks = enc.encode_ordinary(text)
        toks.append(eot)

        # Send val_split fraction to val (random sample, not first-N)
        if val_pos[0] < VAL_TOKENS and random.random() < val_split:
            take = min(len(toks), VAL_TOKENS - val_pos[0])
            val_arr[val_pos[0]:val_pos[0] + take] = toks[:take]
            val_pos[0] += take
            toks = toks[take:]
            source_val += take

        # Rest to train (up to target_train_tokens)
        if toks and train_pos[0] < TOTAL_TRAIN and source_train < target_train_tokens:
            take = min(len(toks), target_train_tokens - source_train,
                       TOTAL_TRAIN - train_pos[0])
            if take <= 0:
                break
            train_arr[train_pos[0]:train_pos[0] + take] = toks[:take]
            train_pos[0] += take
            source_train += take

        n_docs += 1
        if n_docs % flush_every == 0:
            train_arr.flush()
            val_arr.flush()
        if n_docs % 50_000 == 0:
            log(f"  [{source_name}] {n_docs:,} docs | "
                f"train: {source_train:,} / {target_train_tokens:,} tok | "
                f"val: {source_val:,} | {ram_status()}")

        if source_train >= target_train_tokens:
            break

    train_arr.flush()
    val_arr.flush()
    log(f"  [{source_name}] DONE: {source_train:,} train + {source_val:,} val "
        f"from {n_docs:,} docs | {ram_status()}")
    return source_train, source_val


# ---------------------------------------------------------------------------
# Resume / progress
# ---------------------------------------------------------------------------

def load_progress():
    if os.path.exists(PROGRESS_PATH):
        try:
            with open(PROGRESS_PATH) as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_progress(progress):
    tmp = PROGRESS_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(progress, f, indent=2)
    os.replace(tmp, PROGRESS_PATH)  # atomic


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")  # 5-10x faster downloads
    os.makedirs(DATA_DIR, exist_ok=True)

    random.seed(42)
    enc = tiktoken.get_encoding("gpt2")
    eot = enc.eot_token

    log("=== Building all-rounder 5B dataset (v2 — memory-safe) ===")
    log(f"  FineWeb-Edu:  {FINEWEB_TOKENS:,} tok (50%)")
    log(f"  Wikipedia:    {WIKI_TOKENS:,} tok (20%)")
    log(f"  StarCoder2:   {STARCODER_TOKENS:,} tok (15%)  [open alternatives]")
    log(f"  OpenHermes:   {OPENHERMES_TOKENS:,} tok (10%)")
    log(f"  FineMath:     {FINEMATH_TOKENS:,} tok (5%)")
    log(f"  Val (mixed):  {VAL_TOKENS:,} tok")
    log(f"  Total train:  {TOTAL_TRAIN:,} tok")
    log(f"  RAM at start: {ram_status()}")
    log("")

    train_path = os.path.join(DATA_DIR, "train.bin")
    val_path = os.path.join(DATA_DIR, "val.bin")

    # Load any saved positions from a previous interrupted run.
    progress = load_progress()
    resuming = bool(progress) and progress.get("_train_pos", 0) > 0

    if resuming:
        log(f"RESUME: found progress.json — {len(progress.get('_sources_used', {}))} "
            f"sources recorded, train_pos={progress.get('_train_pos', 0):,}, "
            f"val_pos={progress.get('_val_pos', 0):,}")
        # Open existing files read/write (do NOT truncate). If the file is
        # missing or wrong size, fall through to a clean create.
        try:
            train_arr = np.memmap(train_path, dtype=np.uint16,
                                  mode='r+', shape=(TOTAL_TRAIN,))
            val_arr = np.memmap(val_path, dtype=np.uint16,
                                mode='r+', shape=(VAL_TOKENS,))
        except (FileNotFoundError, ValueError) as e:
            log(f"  progress.json found but train.bin/val.bin missing or wrong "
                f"size ({e}). Starting fresh.")
            progress = {}
            resuming = False

    if not resuming:
        log(f"Preallocating train.bin ({TOTAL_TRAIN * 2 / 1e9:.1f} GB) "
            f"and val.bin ({VAL_TOKENS * 2 / 1e6:.1f} MB)...")
        train_arr = np.memmap(train_path, dtype=np.uint16,
                              mode='w+', shape=(TOTAL_TRAIN,))
        val_arr = np.memmap(val_path, dtype=np.uint16,
                            mode='w+', shape=(VAL_TOKENS,))

    train_pos = [progress.get("_train_pos", 0)]
    val_pos = [progress.get("_val_pos", 0)]
    sources_used = progress.get("_sources_used", {})

    # ----- Run each source in order, skipping done ones -----
    for name, target in SOURCES:
        if name in sources_used and sources_used[name].get("done"):
            log(f"SKIP: {name} already done "
                f"({sources_used[name]['train']:,} train + "
                f"{sources_used[name]['val']:,} val)")
            continue

        log(f"--- {name.upper()} (target {target:,} tok) ---")
        iter_fn = SOURCE_ITERATORS[name]
        try:
            s_train, s_val = tokenize_and_stream(
                iter_fn(),
                train_arr, val_arr, train_pos, val_pos,
                target, enc, eot, name,
            )
            sources_used[name] = {
                "train": s_train, "val": s_val, "done": True
            }
        except Exception as e:
            log(f"  [{name}] FAILED: {e}")
            sources_used[name] = {
                "train": 0, "val": 0, "done": False, "error": str(e)
            }

        # Save progress so a crash here doesn't lose earlier sources
        progress["_train_pos"] = train_pos[0]
        progress["_val_pos"] = val_pos[0]
        progress["_sources_used"] = sources_used
        save_progress(progress)

        # CRITICAL: free the dataset's underlying connections / caches
        gc.collect()
        log(f"  after gc: {ram_status()}")

    # ----- Final flush + truncate + meta -----
    log("Flushing and truncating files to actual size...")
    train_arr.flush()
    val_arr.flush()
    del train_arr, val_arr
    gc.collect()

    # CRITICAL: truncate to actual size (otherwise tail is zeros = token "!" = silent corruption)
    os.truncate(train_path, train_pos[0] * np.dtype(np.uint16).itemsize)
    os.truncate(val_path,   val_pos[0]   * np.dtype(np.uint16).itemsize)

    # Remove progress.json (no longer needed once we're done)
    if os.path.exists(PROGRESS_PATH):
        os.remove(PROGRESS_PATH)

    meta = {
        "vocab_size": enc.n_vocab,
        "tokenizer": "gpt2",
        "block_size_hint": 2048,
        "total_train_tokens": int(train_pos[0]),
        "val_tokens": int(val_pos[0]),
        "sources": {k: {kk: vv for kk, vv in v.items() if kk != "done"}
                    for k, v in sources_used.items()},
        "mix_ratio": "50/20/15/10/5 FineWeb-Edu/Wiki/StarCoder/OpenHermes/FineMath",
        "notes": "Modern overtraining ratio (~37x Chinchilla for 135M params). "
                 "Memory-safe v2: all datasets streamed, gc between sources.",
        "val_strategy": "0.1% random sample from each source (mixed-source val)",
    }
    with open(os.path.join(DATA_DIR, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    log("=" * 60)
    log(f"DONE: Dataset built at {DATA_DIR}")
    log(f"  train.bin: {fmt_bytes(os.path.getsize(train_path))} "
        f"({train_pos[0]:,} tokens)")
    log(f"  val.bin:   {fmt_bytes(os.path.getsize(val_path))} "
        f"({val_pos[0]:,} tokens)")
    for name, _ in SOURCES:
        if name in sources_used:
            counts = sources_used[name]
            log(f"  {name}: {counts.get('train', 0):,} train + "
                f"{counts.get('val', 0):,} val"
                + (f"  [ERROR: {counts.get('error')}]"
                   if counts.get("error") else ""))
    log(f"  TOTAL:    {train_pos[0]:,} train (target {TOTAL_TRAIN:,})")
    pct = train_pos[0] / TOTAL_TRAIN * 100
    log(f"  Coverage: {pct:.1f}% of target")
    if pct < 95:
        log("  WARNING: < 95% of target tokens. Training will end early.")
        log("           Consider increasing grad_accum_steps or decreasing max_iters.")
    log("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("\nInterrupted by user. Progress saved to progress.json. "
            "Re-run to resume.")
        sys.exit(130)
    except MemoryError:
        log("\nFATAL: Python raised MemoryError. This should not happen with "
            "streaming + gc. If it does, you're on a machine with < 8 GB RAM.")
        log(f"  RAM at crash: {ram_status()}")
        sys.exit(137)
