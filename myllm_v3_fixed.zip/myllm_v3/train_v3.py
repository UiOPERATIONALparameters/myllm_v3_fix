"""
train_v3.py — Training loop for the 135M all-rounder model.

Improvements over v2:
  - TF32 matmul enabled (3-8x speedup for FP32 ops like RMSNorm/QK-norm)
  - Pinned memory + non_blocking=True (actually works now)
  - loss.item() called ONCE per step (not per micro-batch — fixes torch.compile sync)
  - Returns CE and Z-loss separately for cleaner logging
  - Checkpoint auto-cleanup (keep last N + best)
  - All v2 safety features carried forward (NaN guards, RNG state, emergency ckpts)

USAGE
-----
    # Fresh training (on H100 80GB)
    python train_v3.py

    # Resume from checkpoint
    python train_v3.py --resume out/allrounder_135M/ckpt_best.pt
"""

import argparse
import os
import time
import math
import json
import glob
from contextlib import nullcontext

import numpy as np
import torch
import torch.nn as nn

from config_v3 import get_config, save_config
from model_v3 import GPT


# ---------------------------------------------------------------------------
# Data loading — memmap, with pinned memory for async transfer
# ---------------------------------------------------------------------------
class TokenDataset:
    def __init__(self, path: str, block_size: int):
        self.data = np.memmap(path, dtype=np.uint16, mode="r")
        self.block_size = block_size

    def __len__(self):
        return max(0, len(self.data) - self.block_size - 1)

    def get_batch(self, batch_size: int, device: torch.device):
        # +1 to len so we can include the last valid starting position
        ix = np.random.randint(0, len(self), size=batch_size)
        x = np.stack([self.data[i:i + self.block_size].astype(np.int64) for i in ix])
        y = np.stack([self.data[i + 1:i + 1 + self.block_size].astype(np.int64) for i in ix])
        x = torch.from_numpy(x)
        y = torch.from_numpy(y)
        # Pin memory for async CPU->GPU transfer (only useful if CUDA available)
        if device.type == "cuda":
            x = x.pin_memory().to(device, non_blocking=True)
            y = y.pin_memory().to(device, non_blocking=True)
        else:
            x = x.to(device)
            y = y.to(device)
        return x, y


# ---------------------------------------------------------------------------
# LR schedule: linear warmup -> cosine decay -> min_lr floor
# ---------------------------------------------------------------------------
def get_lr(step: int, cfg) -> float:
    if step < cfg.warmup_iters:
        return cfg.learning_rate * (step + 1) / cfg.warmup_iters
    if step >= cfg.lr_decay_iters:
        return cfg.learning_rate * cfg.min_lr_ratio
    decay_ratio = (step - cfg.warmup_iters) / (cfg.lr_decay_iters - cfg.warmup_iters)
    coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
    min_lr = cfg.learning_rate * cfg.min_lr_ratio
    return min_lr + coeff * (cfg.learning_rate - min_lr)


# ---------------------------------------------------------------------------
# Checkpointing — with auto-cleanup of old periodic checkpoints
# ---------------------------------------------------------------------------
def save_checkpoint(path, model, optimizer, step, best_val, cfg, extra=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    state_dict = model.state_dict()
    state_dict = {
        (k.replace("_orig_mod.", "", 1) if k.startswith("_orig_mod.") else k): v
        for k, v in state_dict.items()
    }
    payload = {
        "model": state_dict,
        "optimizer": optimizer.state_dict(),
        "step": step,
        "best_val_loss": best_val,
        "config": cfg.__dict__,
        "np_rng": np.random.get_state(),
        "torch_rng": torch.get_rng_state(),
        "cuda_rng": torch.cuda.get_rng_state() if torch.cuda.is_available() else None,
    }
    if extra:
        payload.update(extra)
    torch.save(payload, path)
    print(f"  -> checkpoint saved: {path}")


def cleanup_old_checkpoints(out_dir: str, keep_last_n: int):
    """Keep only the last N periodic checkpoints (plus ckpt_best.pt)."""
    if keep_last_n <= 0:
        return
    ckpts = sorted(
        glob.glob(os.path.join(out_dir, "ckpt_[0-9]*.pt")),
        key=lambda p: int(p.split("ckpt_")[-1].split(".pt")[0]),
    )
    for old in ckpts[:-keep_last_n]:
        try:
            os.remove(old)
            print(f"  -> removed old checkpoint: {old}")
        except OSError:
            pass


def load_checkpoint(path, model, optimizer=None):
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    state_dict = ckpt["model"]
    if any(k.startswith("_orig_mod.") for k in state_dict):
        state_dict = {k.replace("_orig_mod.", "", 1): v for k, v in state_dict.items()}
    target = model._orig_mod if hasattr(model, "_orig_mod") else model
    target.load_state_dict(state_dict)
    if optimizer is not None and "optimizer" in ckpt:
        optimizer.load_state_dict(ckpt["optimizer"])
    if "np_rng" in ckpt:
        np.random.set_state(ckpt["np_rng"])
    if "torch_rng" in ckpt:
        torch.set_rng_state(ckpt["torch_rng"])
    if ckpt.get("cuda_rng") is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state(ckpt["cuda_rng"])
    return ckpt.get("step", 0), ckpt.get("best_val_loss", float("inf"))


# ---------------------------------------------------------------------------
# Sample generation — for periodic sanity checks
# ---------------------------------------------------------------------------
@torch.no_grad()
def quick_sample(model, enc, device, prompt_text="The Eiffel Tower is", max_new=100):
    model.eval()
    ids = enc.encode_ordinary(prompt_text)
    if len(ids) == 0:
        ids = [enc.eot_token]
    if len(ids) > model.cfg.block_size:
        ids = ids[-model.cfg.block_size:]
    x = torch.tensor([ids], dtype=torch.long, device=device)
    out = model.generate(x, max_new_tokens=max_new, temperature=0.8, top_k=50, top_p=0.9)
    text = enc.decode(out[0].tolist())
    model.train()
    return text


# ---------------------------------------------------------------------------
# Main training function
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", type=str, default=None)
    parser.add_argument("--device", type=str, default=None)
    args = parser.parse_args()

    cfg = get_config()

    # --- device ---
    if args.device:
        device = torch.device(args.device)
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    print(f"Using device: {device}")

    # --- TF32 enablement (CRITICAL for Ampere+ GPUs: 3-8x speedup for FP32 ops) ---
    if cfg.tf32 and device.type == "cuda":
        torch.set_float32_matmul_precision("high")
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        print("  TF32 enabled (3-8x speedup for FP32 matmuls)")

    # --- Verify GPU is BF16-capable (T4/Turing will fail) ---
    if device.type == "cuda" and cfg.dtype == "bfloat16":
        cap = torch.cuda.get_device_capability(device)
        if cap[0] < 8:  # sm_80 = Ampere (A100, H100, L40S, H200)
            print(f"  WARNING: GPU compute capability {cap} does NOT support BF16 tensor cores.")
            print(f"  BF16 autocast will silently fall back to FP32 (4x slower).")
            print(f"  Use H100, H200, A100, or L40S — NOT T4.")
            raise RuntimeError(
                f"GPU {torch.cuda.get_device_name(device)} (cap {cap}) lacks BF16 support. "
                f"Switch to H100/H200/A100/L40S."
            )

    # --- bf16 autocast (no GradScaler needed for bf16) ---
    ptdtype = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}[cfg.dtype]
    ctx = nullcontext()
    if device.type == "cuda":
        ctx = torch.amp.autocast(device_type="cuda", dtype=ptdtype)
    print(f"  dtype: {cfg.dtype} (bf16 needs no GradScaler)")

    # --- output dir ---
    out_dir = os.path.join(cfg.out_dir, cfg.run_name)
    os.makedirs(out_dir, exist_ok=True)
    save_config(cfg, os.path.join(out_dir, "config.json"))

    # --- data ---
    data_dir = os.path.join(cfg.data_dir, cfg.dataset)
    train_path = os.path.join(data_dir, "train.bin")
    val_path = os.path.join(data_dir, "val.bin")
    assert os.path.exists(train_path), f"Missing {train_path}. Run data/prepare_5b_allrounder.py first."
    assert os.path.exists(val_path),   f"Missing {val_path}.   Run data/prepare_5b_allrounder.py first."

    print(f"Loading data from {data_dir}")
    train_ds = TokenDataset(train_path, cfg.block_size)
    val_ds   = TokenDataset(val_path,   cfg.block_size)
    print(f"  train tokens: {len(train_ds) + cfg.block_size:,}")
    print(f"  val   tokens: {len(val_ds) + cfg.block_size:,}")

    # --- model ---
    model = GPT(cfg).to(device)
    n_params = model.num_params()
    n_non_emb = model.num_params(non_embedding=True)
    print(f"  model params: {n_params/1e6:.2f}M total, {n_non_emb/1e6:.2f}M non-embedding")

    if cfg.compile and hasattr(torch, "compile") and device.type == "cuda":
        try:
            model = torch.compile(model)
            print("  torch.compile() enabled")
        except Exception as e:
            print(f"  torch.compile() failed (continuing without): {e}")

    # --- optimizer ---
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        # Decay 2D+ weights except embeddings (tied with head, also no decay)
        if p.dim() >= 2 and "emb" not in name:
            decay.append(p)
        else:
            no_decay.append(p)
    groups = [
        {"params": decay,    "weight_decay": cfg.weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    optimizer = torch.optim.AdamW(
        groups, lr=cfg.learning_rate,
        betas=(cfg.beta1, cfg.beta2), eps=cfg.eps,
        fused=(device.type == "cuda"),
    )
    print(f"  optimizer: AdamW fused=True  b=({cfg.beta1},{cfg.beta2})  eps={cfg.eps}")
    print(f"  decay params:     {sum(p.numel() for p in decay):,}")
    print(f"  no-decay params:  {sum(p.numel() for p in no_decay):,}")

    # --- resume ---
    start_step = 0
    best_val = float("inf")
    if args.resume:
        start_step, best_val = load_checkpoint(args.resume, model, optimizer)
        print(f"  resumed from {args.resume}")
        print(f"  step {start_step}  best_val {best_val:.4f}")

    # --- eval helper ---
    @torch.no_grad()
    def estimate_loss():
        model.eval()
        out = {}
        for name, ds in [("train", train_ds), ("val", val_ds)]:
            losses = []
            for _ in range(cfg.eval_iters):
                x, y = ds.get_batch(cfg.batch_size, device)
                with ctx:
                    _, loss, ce, _ = model(x, y)
                losses.append(ce.item())  # use CE only (no z-loss in eval)
            out[name] = sum(losses) / len(losses)
        model.train()
        return out

    # --- tokenizer (for periodic sampling) ---
    import tiktoken
    enc = tiktoken.get_encoding("gpt2")

    # --- training loop ---
    print(f"\n=== Training start (max_iters={cfg.max_iters}) ===")
    print(f"  Target: ~{cfg.max_iters * cfg.batch_size * cfg.block_size * cfg.grad_accum_steps / 1e9:.2f}B tokens")
    print(f"  Effective batch: {cfg.batch_size * cfg.block_size * cfg.grad_accum_steps / 1e6:.2f}M tokens/step\n")

    t0 = time.time()
    model.train()
    running_loss = 0.0
    running_ce = 0.0
    running_z = 0.0
    running_count = 0
    peak_mem = 0.0

    for step in range(start_step + 1, cfg.max_iters + 1):
        lr = get_lr(step - 1, cfg)
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        # Accumulate as tensors (no .item() in inner loop — fixes torch.compile sync)
        step_loss_t = torch.zeros((), device=device)
        step_ce_t = torch.zeros((), device=device)
        step_z_t = torch.zeros((), device=device)
        for _ in range(cfg.grad_accum_steps):
            x, y = train_ds.get_batch(cfg.batch_size, device)
            with ctx:
                logits, loss, ce, z = model(x, y)
            if not torch.isfinite(loss):
                save_checkpoint(os.path.join(out_dir, f"ckpt_NaN_step{step}.pt"),
                                model, optimizer, step, best_val, cfg)
                raise RuntimeError(
                    f"Non-finite loss at step {step}: {loss.item()}. "
                    f"Emergency checkpoint saved. Lower LR or check data."
                )
            loss = loss / cfg.grad_accum_steps
            loss.backward()
            step_loss_t += loss.detach()
            step_ce_t += ce.detach() / cfg.grad_accum_steps
            if z is not None:
                step_z_t += z.detach() / cfg.grad_accum_steps
        # Single .item() per step (instead of 32 per step in v2)
        running_loss += step_loss_t.item()
        running_ce += step_ce_t.item()
        running_z += step_z_t.item()
        running_count += 1

        # Grad clip + NaN guard on grad norm
        if cfg.grad_clip:
            grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            if not torch.isfinite(grad_norm):
                save_checkpoint(os.path.join(out_dir, f"ckpt_NaN_grad_step{step}.pt"),
                                model, optimizer, step, best_val, cfg)
                raise RuntimeError(
                    f"Non-finite grad norm at step {step}: {grad_norm.item()}. "
                    f"Emergency checkpoint saved."
                )

        optimizer.step()

        # Periodic param health check
        if step % 200 == 0:
            bad = [n for n, p in model.named_parameters() if not torch.isfinite(p).all()]
            if bad:
                save_checkpoint(os.path.join(out_dir, f"ckpt_NaN_params_step{step}.pt"),
                                model, optimizer, step, best_val, cfg)
                raise RuntimeError(
                    f"NaN/Inf in params at step {step}: {bad[:3]}. "
                    f"Emergency checkpoint saved. Try lowering LR or check for OOM."
                )

        if device.type == "cuda":
            cur_mem = torch.cuda.max_memory_allocated() / 1e9
            if cur_mem > peak_mem:
                peak_mem = cur_mem

        # --- logging ---
        if step % cfg.log_interval == 0:
            avg = running_loss / running_count
            avg_ce = running_ce / running_count
            avg_z = running_z / running_count
            running_loss = 0.0
            running_ce = 0.0
            running_z = 0.0
            running_count = 0
            elapsed = time.time() - t0
            tok_done = (step - start_step) * cfg.batch_size * cfg.block_size * cfg.grad_accum_steps
            tok_per_sec = tok_done / max(elapsed, 1e-9)
            steps_left = cfg.max_iters - step
            eta_sec = (elapsed / max(step - start_step, 1)) * steps_left
            eta_hr = eta_sec / 3600
            print(f"step {step:>6d}  loss {avg:.4f} (ce {avg_ce:.4f} z {avg_z:.4f})  lr {lr:.2e}  "
                  f"{tok_per_sec/1e3:.1f}k tok/s  mem {peak_mem:.1f}GB  ETA {eta_hr:.2f}h")

        # --- eval ---
        if step % cfg.eval_interval == 0 or step == cfg.max_iters:
            losses = estimate_loss()
            print(f"  >> step {step}  train {losses['train']:.4f}  val {losses['val']:.4f}", end="")
            if losses["val"] < best_val:
                best_val = losses["val"]
                print(f"  * NEW BEST")
                save_checkpoint(os.path.join(out_dir, "ckpt_best.pt"),
                                model, optimizer, step, best_val, cfg)
            else:
                print()

        # --- periodic sample ---
        if step % cfg.sample_interval == 0 and step > 0:
            print("\n--- Sample at step", step, "---")
            try:
                sample = quick_sample(model, enc, device, prompt_text="The Eiffel Tower is", max_new=80)
                print(sample)
            except Exception as e:
                print(f"  (sample generation failed: {e})")
            print("---\n")

        # --- periodic checkpoint + cleanup ---
        if step % cfg.checkpoint_interval == 0 or step == cfg.max_iters:
            save_checkpoint(os.path.join(out_dir, f"ckpt_{step}.pt"),
                            model, optimizer, step, best_val, cfg)
            cleanup_old_checkpoints(out_dir, cfg.keep_last_n_checkpoints)

    print(f"\n=== Training complete. Best val loss: {best_val:.4f} ===")
    print(f"Final: {os.path.join(out_dir, f'ckpt_{cfg.max_iters}.pt')}")
    print(f"Best:  {os.path.join(out_dir, 'ckpt_best.pt')}")


if __name__ == "__main__":
    main()
