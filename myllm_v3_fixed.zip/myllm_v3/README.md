# All-rounder 135M LLM (v3)

A **135.2M-parameter decoder-only Transformer** trained on **5B tokens** of mixed data (FineWeb-Edu + Wikipedia + StarCoder + OpenHermes + FineMath). Modern SmolLM2-style architecture, ~37× Chinchilla overtraining ratio, with SFT for chat ability.

## Why this design (vs your v2 plan)

| | v2 (your original) | v3 (this version) |
|---|---|---|
| **Params** | 200M | 135M |
| **Tokens** | 4B | 5B |
| **Ratio** | 20:1 (Chinchilla-optimal) | 37:1 (modern overtraining) |
| **Architecture** | 13L × 1024D (shallow-wide) | 30L × 576D (deep-narrow, SmolLM2-style) |
| **Context** | 1024 | 2048 |
| **Data mix** | 70% Wiki + 30% FineWeb | 50% FineWeb + 20% Wiki + 15% code + 10% chat + 5% math |
| **GPU** | T4 (no BF16 support) | H100 80GB |
| **TF32** | Not enabled | Enabled |
| **Wall-clock** | 52h (claimed) / 140-550h (real) | ~2.5h pretrain + ~30min SFT |
| **Cost** | $10 (claimed) / $26-104 (real) | ~$13.50 pretrain + ~$2.25 SFT = ~$15.75 |
| **Chattable?** | No (base LM only) | Yes (after SFT) |

**Key insight:** At your $14.89 budget on H100, you have ~3 hours of compute. Modern research (SmolLM2, MobileLLM) is unambiguous — at <500M scale, **more tokens > more parameters**. 135M + 5B beats 200M + 4B in basically every published ablation.

## Architecture (135.2M params, SmolLM2-135M-style)

```
n_layer        = 30           (deep)
n_embd         = 576          (narrow)
n_head         = 9            (query heads)
n_kv_head      = 3            (GQA 3:1)
head_dim       = 64
intermediate   = 1536         (SwiGLU, = 8/3 * 576, mult of 64)
vocab_size     = 50304        (GPT-2 BPE, mult of 64)
context        = 2048
tie_embeddings = True         (saves 29M params)
norm           = RMSNorm, pre-norm, eps=1e-5
positional     = RoPE, θ=100000
qk_norm        = Yes          (stability)
z_loss         = 1e-4         (stability)
biases         = None
```

Reference: HuggingFace SmolLM2-135M (released Oct 2024, still SOTA for ~135M in 2025).

## Training (5B tokens, ~2.5 hours on H100)

```
optimizer      = AdamW (fused=True, TF32 enabled)
lr (peak)      = 4e-4
min_lr         = 4e-5         (cosine decay to 0.1× peak)
beta1, beta2   = 0.9, 0.95    (NOT 0.999)
weight_decay   = 0.1          (2D weights only)
grad_clip      = 1.0
warmup         = 200 steps    (2% of total)
total steps    = 10000
effective batch= 524288 tokens (8 micro × 2048 ctx × 32 grad_accum)
dtype          = bfloat16     (H100 native; NOT T4 — T4 lacks BF16)
```

## Data (5B tokens, all-rounder mix)

```
2.5B tokens  FineWeb-Edu (sample-10BT)               — educational web (50%)
1.0B tokens  Wikipedia (20231101.en)                  — encyclopedia facts (20%)
0.75B tokens StarCoder2                                — code (15%)
0.5B tokens  OpenHermes-2.5                           — chat/instruction (10%)
0.25B tokens FineMath-2-plus                          — math reasoning (5%)
5M tokens    Held-out validation (mixed sources)
─────────────────────────────────────────────────────────
5.0B tokens  total training data
```

## Files

| File | Purpose |
|------|---------|
| `config_v3.py` | All hyperparameters and architecture settings |
| `model_v3.py` | The Transformer (GQA + QK-norm + Z-loss + tied embeddings + unrepeated KV cache) |
| `train_v3.py` | Pretraining loop (TF32, NaN guards, RNG state, checkpoint cleanup) |
| `sft_v3.py` | Supervised fine-tuning (ChatML, prompt masking) |
| `sample_v3.py` | Generate text (raw or chat mode) |
| `data/prepare_5b_allrounder.py` | Build the 5B token mixed dataset |
| `setup_lightning.sh` | One-command setup script for Lightning AI |
| `requirements.txt` | Python dependencies |

## Lightning AI — Complete setup guide

### Budget breakdown
- Setup + data prep: **$0** (free CPU)
- Pretraining: **~$11.94** (2.65h × $4.50/hr on H100)
- SFT: **~$2.25** (30min × $4.50/hr on H100)
- Buffer: **~$0.70**
- **Total: ~$14.89** ✅

### Step 1 — Create a Lightning Studio (free, 2 min)

1. Go to https://lightning.ai
2. Click **Studios** → **New Studio**
3. Pick **AI Development** template (PyTorch pre-installed)
4. Name it: `myllm-135M`
5. Click **Create Studio**

It starts on free CPU. No credits used yet.

### Step 2 — Upload and set up (5 min, free CPU)

1. Download `myllm_v3.zip` and drag it into the file explorer (left panel)

2. In the terminal:
   ```bash
   unzip myllm_v3.zip
   cd myllm_v3
   bash setup_lightning.sh
   ```

You should see:
```
OK: Dependencies installed
OK: HF transfer enabled
=== All-rounder 135M config ===
Total params: 135.2M
Compute: 4.25e+18 FLOPs
H100 @ 45% MFU: 2.65 hours = $11.94
```

### Step 3 — Prepare the 5B token dataset (60-90 min, free CPU)

```bash
cd /teamspace/studios/this_studio/myllm_v3
python data/prepare_5b_allrounder.py
```

This downloads ~12 GB of data and tokenizes it. **Still on free CPU. No credits used.**

**Memory-safe v2** (fixes the OOM-kill bug from v1):
- ALL datasets use `streaming=True` — nothing is loaded into RAM whole.
- `gc.collect()` between sources frees the previous iterator.
- A RAM monitor prints RSS + system usage every 50 K docs.
- Per-source checkpoint in `data/allrounder_5b/progress.json` — if the script
  crashes (OOM, network drop, manual Ctrl-C), re-running resumes from the
  last completed source. No more losing 60 minutes of work.
- StarCoder2 source uses OPEN alternatives (`HuggingFaceTB/smollm-corpus`
  `starcoder-python-edu`, then `bigcode/starcoderdata`) instead of the gated
  `bigcode/starcoder2`. No HF login required.

Expected output:
```
[12:00:00] === Building all-rounder 5B dataset (v2 — memory-safe) ===
[12:00:00]   FineWeb-Edu:  2,500,000,000 tok (50%)
[12:00:00]   Wikipedia:    1,000,000,000 tok (20%)
[12:00:00]   StarCoder2:   750,000,000 tok (15%)  [open alternatives]
[12:00:00]   OpenHermes:   500,000,000 tok (10%)
[12:00:00]   FineMath:     250,000,000 tok (5%)
[12:00:00]   Total train:  5,000,000,000 tok
[12:00:00]   RAM at start: RSS=0.4GB  sys used=1.2GB / 16.0GB  (8%)  avail=14.8GB
[12:00:00] Preallocating train.bin (10.0 GB) and val.bin (10.0 MB)...
[12:00:00] --- FINEWEB (target 2,500,000,000 tok) ---
[12:25:00]   [fineweb] DONE: 2,500,000,000 train + 2,500,000 val | RSS=0.8GB ...
[12:25:00]   after gc: RSS=0.6GB  sys used=2.0GB / 16.0GB  (13%)  avail=14.0GB
[12:25:00] --- WIKIPEDIA (target 1,000,000,000 tok) ---
[12:55:00]   [wikipedia] DONE: 1,000,000,000 train + 1,000,000 val | RSS=0.9GB ...
[13:00:00] --- STARCODER (target 750,000,000 tok) ---
[13:20:00]   [starcoder] DONE: 750,000,000 train + 750,000 val | RSS=1.0GB ...
[13:25:00] --- OPENHERMES (target 500,000,000 tok) ---
[13:35:00]   [openhermes] DONE: 500,000,000 train + 500,000 val | RSS=0.9GB ...
[13:40:00] --- FINEMATH (target 250,000,000 tok) ---
[13:50:00]   [finemath] DONE: 250,000,000 train + 250,000 val | RSS=0.8GB ...

============================================================
DONE: Dataset built at data/allrounder_5b
  train.bin: 10.00 GB (5,000,000,000 tokens)
  val.bin:   10.00 MB (5,000,000 tokens)
  Coverage: 100.0% of target
============================================================
```

### Step 4 — Switch to H100 80GB (CREDITS START HERE)

1. Top-right of screen → click **CPU**
2. Select **H100** (80 GB VRAM, $4.50/hour)
3. Click **Confirm**
4. Wait ~30 seconds for GPU to spin up

**Verify the GPU:**
```bash
nvidia-smi
```
You should see `NVIDIA H100 80GB HBM3`. If you see `T4` or `A100`, switch — you need H100.

**Verify BF16 support:**
```bash
python -c "import torch; print(f'cap={torch.cuda.get_device_capability()}'); print(f'BF16 supported: {torch.cuda.get_device_capability()[0] >= 8}')"
```
Should print `cap=(9, 0)` and `BF16 supported: True`.

### Step 5 — Start pretraining (~2.5 hours, ~$12)

```bash
cd /teamspace/studios/this_studio/myllm_v3
python train_v3.py
```

Expected output:
```
Using device: cuda
  TF32 enabled (3-8x speedup for FP32 matmuls)
  dtype: bfloat16 (bf16 needs no GradScaler)
Loading data from data/allrounder_5b
  train tokens: 5,000,000,000
  val   tokens: 5,000,000
  model params: 135.18M total, 106.21M non-embedding
  torch.compile() enabled
  optimizer: AdamW fused=True  b=(0.9,0.95)  eps=1e-08

=== Training start (max_iters=10000) ===
  Target: ~5.24B tokens
  Effective batch: 0.52M tokens/step

step     10  loss 10.5234 (ce 10.5122 z 0.0112)  lr 2.00e-05  85.3k tok/s  mem 4.2GB  ETA 2.91h
step    100  loss 7.2341 (ce 7.2231 z 0.0110)  lr 2.00e-04  142.1k tok/s  mem 4.5GB  ETA 1.75h
...
```

**You can close the browser now.** Lightning runs scripts in the background — training continues even if you disconnect. Checkpoints save every 1000 steps.

### Step 6 — Do SFT (~30 min, ~$2.25)

After pretraining finishes:
```bash
python sft_v3.py --base out/allrounder_135M/ckpt_best.pt
```

This trains on OpenHermes-2.5 with ChatML template. ~2000 steps, ~25 minutes.

### Step 7 — Chat with your model

```bash
python sample_v3.py --checkpoint out/allrounder_135M_sft/ckpt_sft.pt --interactive
```

You'll get a `>>> ` prompt. Type a question, press Enter, get a response.

### Step 8 — STOP THE MACHINE (CRITICAL!)

When done, top-right → **Stop** the machine. Credits stop. Your files and checkpoints persist.

## If things go wrong

| Problem | Fix |
|---|---|
| `Killed` during data prep (no traceback) | Linux OOM killer. v2 of the script fixes this — all datasets stream. Re-run `python data/prepare_5b_allrounder.py`; it resumes from `progress.json`. |
| `Dataset '...' is a gated dataset` | Run `huggingface-cli login`, then click "Agree and access repository" on the dataset's HF page. v2 uses OPEN alternatives by default, so this should only happen if you edit the script to use gated sources. |
| Data prep crashed mid-way | Just re-run the script. It auto-resumes from the last completed source via `data/allrounder_5b/progress.json`. To start fresh: `rm -rf data/allrounder_5b` |
| `RuntimeError: GPU ... lacks BF16 support` | You're on T4. Switch to H100. |
| `CUDA out of memory` | Edit `config_v3.py`: `batch_size: 8` → `4`, `grad_accum_steps: 32` → `64`. Same effective batch. |
| `Non-finite loss at step N` | Emergency checkpoint saved. Lower `learning_rate: 4e-4` → `2e-4`, then resume. |
| Training crashed | `python train_v3.py --resume out/allrounder_135M/ckpt_best.pt` |
| Out of disk | `rm out/allrounder_135M/ckpt_[0-9]*.pt` (keeps only `ckpt_best.pt`) |
| Generation is gibberish | Pretraining didn't finish. Loss should be < 2.5 for readable output. |
| Out of budget before SFT | Skip SFT, use base model: `python sample_v3.py --checkpoint out/allrounder_135M/ckpt_best.pt` |

## After training

You'll have a **135M all-rounder LLM** that can:
- ✅ Write fluent English
- ✅ Recall Wikipedia facts
- ✅ Write simple code (Python, JS, etc.)
- ✅ Do basic math
- ✅ Follow chat instructions (after SFT)
- ✅ Have multi-turn conversations (after SFT)

What it can't do (need >1B params):
- ❌ Complex reasoning
- ❌ Long-context tasks (>2048 tokens)
- ❌ Advanced coding (debugging, refactoring)
- ❌ Multi-lingual (English only — GPT-2 BPE)

## Cost summary

| Stage | Time | Cost |
|---|---|---|
| Setup (CPU) | 5 min | $0 (free CPU) |
| Data prep (CPU) | 60-90 min | $0 (free CPU) |
| Pretraining (H100) | 2.65 h | $11.94 |
| SFT (H100) | 0.5 h | $2.25 |
| **Total** | ~3.5 h | **~$14.19** |
| **Budget** | — | **$14.89** |
| **Buffer** | — | **$0.70** |

If pretraining runs over budget (worse MFU than expected), skip SFT and use the base model for raw text completion.
